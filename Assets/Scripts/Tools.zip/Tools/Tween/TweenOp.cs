using System;
using System.Collections.Generic;
using UnityEngine;
using static Tween;
public static class TweenOp{
    static public bool TryGetTrack(this Tween self, string trackName, out TweenTrack track)
    => self.tweenDict.TryGetValue(trackName, out track);
    static public TweenTrack GetOrAddTrack(this Tween self, string trackName)
    {
        if (!self.TryGetTrack(trackName, out var track))
        {
            track = new TweenTrack() { name = trackName };
            self.tweenDict[trackName] = track;
        }
        return track;
    }
    static public Dictionary<string, Variant> GetContext(this Tween self, string trackName)
        => self.tweenDict[trackName].context;
    public static TweenTrack AddTweenValue<T>(this Tween tween, string trackName, Action<T> setter, T start, T end, float time,
            TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.GetOrAddTrack(trackName).AddTweenValue(setter, start, end, time, transitionType, easeType);
    public static TweenTrack AddTweenValue<T>(this Tween tween,
                                              Action<T> setter,
                                              T start,
                                              T end,
                                              float time,
                                              TransitionType transitionType = TransitionType.LINEAR,
                                              EaseType easeType = EaseType.IN)
        => tween.AddTweenValue<T>("__default", setter, start, end, time, transitionType, easeType);
    public static TweenTrack AddTweenGetter<T>(this Tween tween,string trackName, Action<T> setter, Func<T> getter, T end, float time,
           TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.GetOrAddTrack(trackName).AddTweenGetter(setter, getter, end, time, transitionType, easeType);

    public static TweenTrack AddTweenGetter<T>(this Tween tween, Action<T> setter, Func<T> getter, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.AddTweenGetter<T>("__default", setter, getter, end, time, transitionType, easeType);
    public static TweenTrack AddTweenOffset<T>(this Tween tween,string trackName, Action<T> setter, Func<T> getter, T offset, float time,
       TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.GetOrAddTrack(trackName).AddTweenOffset(setter,getter,offset,time,transitionType,easeType );

    public static TweenTrack AddTweenOffset<T>(this Tween tween,Action<T> setter, Func<T> getter, T end, float time,
    TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.AddTweenOffset("__default", setter, getter, end, time, transitionType, easeType);

    public static TweenTrack AddTween<T>(this Tween tween,
        Action<T> setter, T start, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.AddTweenValue<T>(setter, start, end, time, transitionType, easeType);
    public static TweenTrack AddTween<T>(this Tween tween,
        Action<T> setter, Func<T> getter, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.AddTweenGetter<T>(setter, getter, end, time, transitionType, easeType);
    public static TweenTrack AddTween<T>(this Tween tween, string trackName,
        Action<T> setter, T start, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.AddTweenValue<T>(trackName, setter, start, end, time, transitionType, easeType);
    public static TweenTrack AddTween<T>(this Tween tween, string trackName,
        Action<T> setter, Func<T> getter, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => tween.AddTweenGetter<T>(trackName, setter, getter, end, time, transitionType, easeType);
    public static TweenTrack AddTween(this Tween tween, string trackName, Func<bool> func)
        => tween.GetOrAddTrack(trackName).AddTween(func);
    public static TweenTrack AddTween(this Tween tween, Func<bool> func)
        => tween.AddTween("__default", func);
    
    public static TweenTrack AddTweenWait(this Tween tween, string name, int count)
        => tween.DefaultTrack.AddTweenWait(name, count);
    public static TweenTrack AddTweenWait(this Tween tween, string trackName, string name, int count)
        => tween.GetOrAddTrack(trackName).AddTweenWait(name, count);
    public static TweenTrack AddTweenSignal(this Tween tween, string name, int offset)
        => tween.DefaultTrack.AddTweenSignal(name, offset);
    public static TweenTrack AddTweenSignal(this Tween tween, string trackName, string name, int offset)
        => tween.GetOrAddTrack(trackName).AddTweenSignal(name, offset);
}

public static class TweenTrackOp
{
    public static TweenTrack AddTween(this TweenTrack track, TweenNodeBase tweenNode,
            TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
    {
        if (track._tweenState == Tween.TweenState.RUNNING)
        {
            Debug.LogError("Try to call AddTween while tween is running");
            return track;
        }

        var cTime = 0f;
        var tweenNodeList = track.tweenNodeList;
        if (tweenNodeList.Count > 0)
            cTime = tweenNodeList[tweenNodeList.Count - 1].Duration;

        tweenNode.EaseType = easeType;
        tweenNode.TransitionType = transitionType;
        tweenNode.master = track;
        tweenNodeList.Add(tweenNode);
        return track;
    }

    public static TweenTrack AddTweenValue<T>(this TweenTrack track, Action<T> setter, T start, T end, float time,
            TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
            => track.AddTween(new TweenValueNode<T>(setter, start, end, time), transitionType, easeType);

    public static TweenTrack AddTweenGetter<T>(this TweenTrack track, Action<T> setter, Func<T> getter, T end, float time,
           TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
            => track.AddTween(new TweenGetterNode<T>(setter, getter, end, time), transitionType, easeType);

    public static TweenTrack AddTweenOffset<T>(this TweenTrack track, Action<T> setter, Func<T> getter, T offset, float time,
       TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
            => track.AddTween(new TweenOffsetNode<T>(setter, getter, offset, time), transitionType, easeType);
    public static TweenTrack AddTweenWait(this TweenTrack track, string name, int count)
            => track.AddTween(new TweenWait(name, count));
    public static TweenTrack AddTweenSignal(this TweenTrack track, string name, int offset)
            => track.AddTween(new TweenSignal(name, offset));
    public static TweenTrack AddTween<T>(this TweenTrack track,
        Action<T> setter, T start, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => track.AddTweenValue<T>(setter, start, end, time, transitionType, easeType);
    public static TweenTrack AddTween<T>(this TweenTrack track,
        Action<T> setter, Func<T> getter, T end, float time,
        TransitionType transitionType = TransitionType.LINEAR, EaseType easeType = EaseType.IN)
        => track.AddTweenGetter<T>(setter, getter, end, time, transitionType, easeType);
    public static TweenTrack AddTween(this TweenTrack track, Func<bool> func)
        => track.AddTween(new TweenUtil { func = func });
}


