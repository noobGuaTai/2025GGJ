using JetBrains.Annotations;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using static Tween;

public class TweenContext
{
	public static Tween Tween { get; internal set; }
	public static TweenTrack TweenTrack { get; internal set; }
	public static Dictionary<string, Variant> Context => TweenTrack.context;
}

public class Tween : MonoBehaviour
{
	// Start is called before the first frame update
	void Start()
	{

	}
	public TweenTrack DefaultTrack => this.GetOrAddTrack("__default");
	public enum TweenType
	{
		UNKNOWN = -1,
		FLOAT,
		VECTOR2,
		VECTOR3,
		VECTOR2INT,
		VECTOR3INT,
	}

	public enum TweenState
	{
		STOP,
		RUNNING,
		PAUSED,
	}

	public enum PlayMode
	{
		NORMAL,
		REPEAT,
		REVERSE,
	}
	abstract public class TweenNodeBase
	{
		abstract public float Duration { set; get; }
		abstract public TransitionType TransitionType { set; get; }
		abstract public EaseType EaseType { set; get; }
		public TweenTrack master;
		abstract public bool Run();
		virtual public float TimeFactor => 0f;
	}


	abstract public class TweenNodeBaseTime : TweenNodeBase
	{
		public TransitionType transitionType = TransitionType.LINEAR;
		public EaseType easeType = EaseType.IN;
		override public TransitionType TransitionType { set => transitionType = value; get => transitionType; }
		override public EaseType EaseType { set => easeType = value; get => easeType; }
		public float duration;
		public override float Duration { get => duration; set => duration = value; }
		abstract public void Tick(float alpha);
		public override float TimeFactor => 1f;
		public override bool Run()
		{
			Tick(master.CurrenEaseAlpha);
			return master.CurrenLinearAlpha >= 1;
		}
	}

	[System.Serializable]
	public class TweenTrack
	{
		public Action OnFinishPlay;
		public Dictionary<string, Variant> context = new();
		public string name;
		public TweenState _tweenState;
		public TweenNodeBase CurrentTweenNode => tweenNodeList[tweenIndex];
		public float PreTime => tweenIndex >= 1 ? tweenNodeEndTime[tweenIndex - 1] : 0;
		public float CurrenLinearAlpha => Mathf.Clamp01((tweenTime - PreTime) / (CurrentTweenNode.Duration + 1e-6f));
		public float CurrenEaseAlpha => EaseAndTrainsitionProcess(CurrenLinearAlpha, CurrentTweenNode.EaseType, CurrentTweenNode.TransitionType);
		public int tweenIndex = 0;
		public float tweenTime = 0;
		PlayMode _playMode = PlayMode.NORMAL;

		// when doing (clear -> addtween -> play) in function like setter or getter
		// then should stop cnt tween process
		public bool stopFlag = false;
		public PlayMode playMode
		{
			set
			{
				_playMode = value;
			}
			get
			{
				return _playMode;
			}
		}
		public TweenTrack SetPlayMode(PlayMode value) { playMode = value; return this; }
		public bool clearWhenEnd = true;
		public TweenTrack SetClearWhenEnd(bool value) { clearWhenEnd = value; return this; }
		public TweenNodeBase lastActiveTween;
		public List<TweenNodeBase> tweenNodeList = new();
		public List<float> tweenNodeEndTime = new();
		public float Duration => tweenNodeEndTime.Count > 0 ? tweenNodeEndTime.Last() : 0;
		public void Play()
		{
			if (_tweenState == Tween.TweenState.RUNNING || tweenNodeList.Count == 0)
				return;

			_tweenState = Tween.TweenState.RUNNING;
			lastActiveTween = null;

			tweenNodeEndTime.Clear();
			if (tweenNodeList.Count > 0)
				tweenNodeEndTime.Add(tweenNodeList[0].Duration);
			for (int i = 1; i < tweenNodeList.Count; i++)
				tweenNodeEndTime.Add(tweenNodeEndTime[i - 1] + tweenNodeList[i].Duration);

			if (playMode == PlayMode.REVERSE)
			{
				tweenTime = Duration;
				tweenIndex = tweenNodeList.Count - 1;
			}
			else
			{
				tweenIndex = 0;
				tweenTime = 0;
			}
		}
		public void Clear()
		{
			_tweenState = TweenState.STOP;
			tweenNodeList.Clear();
			stopFlag = true;
		}
		public bool isPlaying => _tweenState == TweenState.RUNNING;


	}
	public Dictionary<string, TweenTrack> tweenDict = new Dictionary<string, TweenTrack>();
	public void Clear(string trackName = "__default", bool noWarning = false)
	{
		if (tweenDict.TryGetValue(trackName, out var track))
		{
			track.Clear();
		}
		else
		{
			if (!noWarning)
				Debug.LogWarning($"Tween.Clear: track named({trackName}) not find");
		}
	}
	public void ClearAll() => tweenDict.ToList().ForEach(x => x.Value.Clear());
	public void Play()
	{
		foreach (var pair in tweenDict)
		{
			pair.Value.Play();
		}
	}

	public void Play(TweenTrack track)
	{
		track.Play();
	}

	public void Play(string trackName)
	{
		if (tweenDict.TryGetValue(trackName, out var track))
		{
			Play(track);
			return;
		}
		Debug.LogError("Tween: Unkown track named:" + trackName);
	}
	public void Play(params string[] trackNames)
	{
		foreach (var p in trackNames)
			Play(p);
	}

	public void Stop()
	{
		foreach (var pair in tweenDict)
		{
			var track = pair.Value;
			ref var _tweenState = ref pair.Value._tweenState;
			var tweenNodeList = pair.Value.tweenNodeList;
			_tweenState = Tween.TweenState.STOP;
			if (track.playMode == PlayMode.REVERSE)
			{
				track.tweenTime = track.Duration;
				track.tweenIndex = tweenNodeList.Count - 1;
			}
			else
			{
				track.tweenIndex = 0;
				track.tweenTime = 0;
			}

		}
	}

	public void Pause()
	{
		foreach (var pair in tweenDict)
		{
			ref var _tweenState = ref pair.Value._tweenState;
			_tweenState = Tween.TweenState.PAUSED;
		}
	}

	//void tweenCall<T>(TweenValueNode<T> tweenNode, float alpha)
	//{
	//    var cntT = (tweenNode.end - tweenNode.start) * alpha + tweenNode.start;
	//    tweenNode.setter(cntT);
	//}

	bool TweenProcess(TweenTrack track, TweenNodeBase tweenNodeBase)
	{
		var finish = tweenNodeBase.Run();
		track.lastActiveTween = tweenNodeBase;
		return finish;
	}

	// Update is called once per frame
	public void Update()
	{
		TweenContext.Tween = this;
		foreach (var pair in tweenDict.ToList())
		{
			var track = pair.Value;
			TweenContext.TweenTrack = track;

			ref var _tweenState = ref pair.Value._tweenState;
			var tweenNodeList = pair.Value.tweenNodeList;
			if (_tweenState != TweenState.RUNNING)
				continue;
			track.stopFlag = false;

			var delTime = Time.deltaTime;
			if (track.playMode == PlayMode.REVERSE)
				track.tweenTime -= delTime * track.CurrentTweenNode.TimeFactor;
			else
				track.tweenTime += delTime * track.CurrentTweenNode.TimeFactor;

			Action loopProcess = () =>
			{
				float cntAlpha = track.CurrenEaseAlpha;
				if (track.playMode == PlayMode.REVERSE)
				{
					while (true)
					{
						if (track.tweenIndex < 0) break;
						var finish = TweenProcess(track, tweenNodeList[track.tweenIndex]);
						if (track.stopFlag) return;
						if (finish) track.tweenIndex--;
						else break;
					}
					return;
				}
				else
				{
					while (true)
					{
						if (track.tweenIndex >= track.tweenNodeList.Count) break;
						var finish = TweenProcess(track, tweenNodeList[track.tweenIndex]);
						if (track.stopFlag) return;
						if (finish) track.tweenIndex++;
						else break;
					}
				}
			};
			loopProcess();
			if (track.stopFlag) continue;
			Func<bool> endCondition = () =>
			{
				if (track.playMode == PlayMode.REVERSE)
				{
					return track.tweenIndex == -1;
				}
				else
				{
					return track.tweenIndex == tweenNodeList.Count;
				}
			};

			if (endCondition())
			{
				switch (track.playMode)
				{
					case PlayMode.NORMAL:
						_tweenState = TweenState.STOP;
						if (track.clearWhenEnd)
							Clear(track.name);
						track.OnFinishPlay?.Invoke();
						continue;
					case PlayMode.REPEAT:
						track.tweenIndex = 0;
						track.tweenTime -= track.Duration;
						loopProcess();
						track.OnFinishPlay?.Invoke();
						continue;
					case PlayMode.REVERSE:
						_tweenState = TweenState.STOP;
						if (track.clearWhenEnd)
							Clear(track.name);
						track.OnFinishPlay?.Invoke();
						continue;
				}

			}

			if (track.stopFlag) continue;
		}
	}

	public enum TransitionType
	{
		LINEAR,
		SIN,
		QUAD,
		CUBIC,
		QUART,
		QUINT,
		EXP,
		BACK,
		CIRC,
	}

	// return x that f(x)=0.5
	static float GetTransitionTypeInoutFactor(TransitionType type)
	{
		switch (type)
		{
			case TransitionType.LINEAR:
				return 0.5f;
			case TransitionType.SIN:
				return 0.333333333f;
			case TransitionType.QUAD:
				return 0.707107f;
			case TransitionType.CUBIC:
				return 0.793701f;
			case TransitionType.QUART:
				return 0.840896f;
			case TransitionType.QUINT:
				return 0.870551f;
			case TransitionType.EXP:
				return 0.900141f;
			case TransitionType.BACK:
				return 0.8728f;
			case TransitionType.CIRC:
				return 0.866025f;
			default:
				Debug.LogError("Unknown transition type");
				return -1;
		}
	}
	public enum EaseType
	{
		IN,
		OUT,
		IN_OUT,
		OUT_IN,
	}
	public static float TransitionProcess(float alpha, TransitionType type)
	{
		switch (type)
		{
			case TransitionType.LINEAR:
				return alpha;
			case TransitionType.SIN:
				return Mathf.Sin(alpha * 0.5f * Mathf.PI);
			case TransitionType.QUAD:
				return alpha * alpha;
			case TransitionType.CUBIC:
				return alpha * alpha * alpha;
			case TransitionType.QUART:
				return alpha * alpha * alpha * alpha;
			case TransitionType.QUINT:
				return alpha * alpha * alpha * alpha * alpha;
			case TransitionType.EXP:
				return (Mathf.Pow(2, 10 * alpha - 10) - Mathf.Pow(2, -10)) * (1 / (1 - Mathf.Pow(2, -10)));
			case TransitionType.BACK:
				const float c1 = 1.70158f;
				const float c3 = c1 + 1;
				return c3 * alpha * alpha * alpha - c1 * alpha * alpha;
			case TransitionType.CIRC:
				return 1 - Mathf.Sqrt(1 - alpha * alpha);
		}
		Debug.LogError("Unknow transition!");
		return -1;
	}

	public static float EaseAndTrainsitionProcess(
		float alpha, EaseType easeType, TransitionType transitionType)
	{
		var factor = 0.0f;
		switch (easeType)
		{
			case EaseType.IN:
				return TransitionProcess(alpha, transitionType);
			case EaseType.OUT:
				return 1 - TransitionProcess(1 - alpha, transitionType);
			case EaseType.IN_OUT:
				factor = GetTransitionTypeInoutFactor(transitionType) * 2; // equal to divide 0.5
				if (alpha < 0.5f)
				{
					return TransitionProcess(factor * alpha, transitionType);
				}
				else
				{
					return 1 - TransitionProcess(factor * (1 - alpha), transitionType);
				}
			case EaseType.OUT_IN:
				factor = GetTransitionTypeInoutFactor(transitionType) * 2; // equal to divide 0.5
				if (alpha < 0.5f)
				{
					return 0.5f - TransitionProcess(factor * (1 - alpha), transitionType);
				}
				else
				{
					return 0.5f + TransitionProcess(factor * alpha, transitionType);
				}
		}
		Debug.LogError("Unknow transition!");
		return -1;
	}

	public bool AnyPlaying
	{
		get
		{
			foreach (var t in tweenDict.Values)
			{
				if (t.isPlaying) return true;
			}
			return false;
		}
	}
}