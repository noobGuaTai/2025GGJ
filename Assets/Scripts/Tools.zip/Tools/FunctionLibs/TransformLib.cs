using UnityEngine;

public static class TransformExtensions
{
    // 位置相关扩展方法
    public static void SetPosX(this Transform transform, float newX)
    {
        var pos = transform.position;
        pos.x = newX;
        transform.position = pos;
    }

    public static void SetPosY(this Transform transform, float newY)
    {
        var pos = transform.position;
        pos.y = newY;
        transform.position = pos;
    }

    public static void SetPosZ(this Transform transform, float newZ)
    {
        var pos = transform.position;
        pos.z = newZ;
        transform.position = pos;
    }

    public static void SetPosXY(this Transform transform, float newX, float newY)
    {
        var pos = transform.position;
        pos.x = newX;
        pos.y = newY;
        transform.position = pos;
    }

    public static void SetPosYZ(this Transform transform, float newY, float newZ)
    {
        var pos = transform.position;
        pos.y = newY;
        pos.z = newZ;
        transform.position = pos;
    }

    public static void SetPosXZ(this Transform transform, float newX, float newZ)
    {
        var pos = transform.position;
        pos.x = newX;
        pos.z = newZ;
        transform.position = pos;
    }

    // 旋转相关扩展方法（使用欧拉角）
    public static void SetRotX(this Transform transform, float newX)
    {
        var rot = transform.eulerAngles;
        rot.x = newX;
        transform.eulerAngles = rot;
    }

    public static void SetRotY(this Transform transform, float newY)
    {
        var rot = transform.eulerAngles;
        rot.y = newY;
        transform.eulerAngles = rot;
    }

    public static void SetRotZ(this Transform transform, float newZ)
    {
        var rot = transform.eulerAngles;
        rot.z = newZ;
        transform.eulerAngles = rot;
    }

    public static void SetRotXY(this Transform transform, float newX, float newY)
    {
        var rot = transform.eulerAngles;
        rot.x = newX;
        rot.y = newY;
        transform.eulerAngles = rot;
    }

    public static void SetRotYZ(this Transform transform, float newY, float newZ)
    {
        var rot = transform.eulerAngles;
        rot.y = newY;
        rot.z = newZ;
        transform.eulerAngles = rot;
    }

    public static void SetRotXZ(this Transform transform, float newX, float newZ)
    {
        var rot = transform.eulerAngles;
        rot.x = newX;
        rot.z = newZ;
        transform.eulerAngles = rot;
    }

    // 缩放相关扩展方法
    public static void SetScaleX(this Transform transform, float newX)
    {
        var scale = transform.localScale;
        scale.x = newX;
        transform.localScale = scale;
    }

    public static void SetScaleY(this Transform transform, float newY)
    {
        var scale = transform.localScale;
        scale.y = newY;
        transform.localScale = scale;
    }

    public static void SetScaleZ(this Transform transform, float newZ)
    {
        var scale = transform.localScale;
        scale.z = newZ;
        transform.localScale = scale;
    }

    public static void SetScaleXY(this Transform transform, float newX, float newY)
    {
        var scale = transform.localScale;
        scale.x = newX;
        scale.y = newY;
        transform.localScale = scale;
    }

    public static void SetScaleYZ(this Transform transform, float newY, float newZ)
    {
        var scale = transform.localScale;
        scale.y = newY;
        scale.z = newZ;
        transform.localScale = scale;
    }

    public static void SetScaleXZ(this Transform transform, float newX, float newZ)
    {
        var scale = transform.localScale;
        scale.x = newX;
        scale.z = newZ;
        transform.localScale = scale;
    }
}
