using UnityEngine;
using System.Globalization;

/// <summary>
/// VectorLib 扩展库，提供了一系列对 Vector3、Vector2 以及 float 的扩展方法，
/// 包括长度计算、归一化判断、限制长度、向量投影、反射、插值、旋转、夹角、距离计算以及类型转换方法。
/// </summary>
public static class VectorLib
{
    /// <summary>
    /// 获取当前 Vector3 的长度（从原点到该向量的距离）。
    /// </summary>
    /// <param name="vector">目标向量</param>
    /// <returns>向量长度</returns>
    public static float Length(this Vector3 vector)
    {
        return Vector3.Distance(Vector3.zero, vector);
    }

    /// <summary>
    /// 判断当前 Vector3 是否为归一化向量（长度是否约等于 1）。
    /// </summary>
    /// <param name="vector">目标向量</param>
    /// <returns>如果向量归一化返回 true，否则返回 false</returns>
    public static bool IsNormalized(this Vector3 vector)
    {
        return Mathf.Approximately(vector.sqrMagnitude, 1f);
    }

    /// <summary>
    /// 限制当前向量的长度，如果超出 maxLength，则返回一个长度为 maxLength 的向量，
    /// 否则返回原向量。
    /// </summary>
    /// <param name="vector">目标向量</param>
    /// <param name="maxLength">最大允许的长度</param>
    /// <returns>限制后的向量</returns>
    public static Vector3 Limit(this Vector3 vector, float maxLength)
    {
        return vector.magnitude > maxLength ? vector.normalized * maxLength : vector;
    }

    /// <summary>
    /// 将当前向量投影到指定的法线方向上。
    /// </summary>
    /// <param name="vector">目标向量</param>
    /// <param name="normal">投影方向（法线）</param>
    /// <returns>投影后的向量</returns>
    public static Vector3 Project(this Vector3 vector, Vector3 normal)
    {
        normal.Normalize();
        return Vector3.Dot(vector, normal) * normal;
    }

    /// <summary>
    /// 计算当前向量关于指定法线的反射向量。
    /// </summary>
    /// <param name="vector">入射向量</param>
    /// <param name="normal">反射面的法线</param>
    /// <returns>反射后的向量</returns>
    public static Vector3 Reflect(this Vector3 vector, Vector3 normal)
    {
        normal.Normalize();
        return vector - 2 * Vector3.Dot(vector, normal) * normal;
    }

    /// <summary>
    /// 对两个向量进行线性插值，插值因子 t 会被限制在 [0, 1] 范围内。
    /// </summary>
    /// <param name="start">起始向量</param>
    /// <param name="end">目标向量</param>
    /// <param name="t">插值因子</param>
    /// <returns>插值后的向量</returns>
    public static Vector3 Lerp(this Vector3 start, Vector3 end, float t)
    {
        return Vector3.Lerp(start, end, Mathf.Clamp01(t));
    }

    /// <summary>
    /// 以指定的最大弧度角增量，将当前向量旋转至目标向量方向。
    /// </summary>
    /// <param name="current">当前向量</param>
    /// <param name="target">目标向量</param>
    /// <param name="maxRadiansDelta">每次旋转允许的最大弧度</param>
    /// <returns>旋转后的向量</returns>
    public static Vector3 RotateTowards(this Vector3 current, Vector3 target, float maxRadiansDelta)
    {
        return Vector3.RotateTowards(current, target, maxRadiansDelta, 0f);
    }

    /// <summary>
    /// 计算当前向量与目标向量之间的夹角（单位：度）。
    /// </summary>
    /// <param name="from">起始向量</param>
    /// <param name="to">目标向量</param>
    /// <returns>两个向量之间的夹角</returns>
    public static float AngleTo(this Vector3 from, Vector3 to)
    {
        return Vector3.Angle(from, to);
    }

    /// <summary>
    /// 绕指定轴旋转当前向量一定角度（单位：度）。
    /// </summary>
    /// <param name="vec">待旋转的向量</param>
    /// <param name="axis">旋转轴</param>
    /// <param name="degree">旋转角度（度）</param>
    /// <returns>旋转后的向量</returns>
    public static Vector3 Rotate(this Vector3 vec, Vector3 axis, float degree)
    {
        axis.Normalize();
        return Quaternion.AngleAxis(degree, axis) * vec;
    }

    /// <summary>
    /// 计算当前向量与目标向量之间的距离。
    /// </summary>
    /// <param name="from">起始向量</param>
    /// <param name="to">目标向量</param>
    /// <returns>两向量之间的距离</returns>
    public static float DistanceTo(this Vector3 from, Vector3 to)
    {
        return Vector3.Distance(from, to);
    }

    // 转换扩展方法

    /// <summary>
    /// 将 float 转换为 Vector2，x 和 y 均设置为该值。
    /// </summary>
    /// <param name="v">浮点数</param>
    /// <returns>转换后的 Vector2</returns>
    public static Vector2 ToVector2(this float v) => new Vector2(v, v);

    /// <summary>
    /// 将 float 转换为 Vector3，x、y、z 均设置为该值。
    /// </summary>
    /// <param name="v">浮点数</param>
    /// <returns>转换后的 Vector3</returns>
    public static Vector3 ToVector3(this float v) => new Vector3(v, v, v);

    /// <summary>
    /// 将 Vector3 转换为 float，仅返回 x 分量（常用于取代 Vector3 的单一数值）。
    /// </summary>
    /// <param name="v">Vector3 向量</param>
    /// <returns>x 分量值</returns>
    public static float ToFloat(this Vector3 v) => v.x;

    /// <summary>
    /// 将 Vector2 转换为 float，仅返回 x 分量。
    /// </summary>
    /// <param name="v">Vector2 向量</param>
    /// <returns>x 分量值</returns>
    public static float ToFloat(this Vector2 v) => v.x;

    /// <summary>
    /// 将 Vector3 转换为 Vector2，保留 x 和 y 分量，舍弃 z 分量。
    /// </summary>
    /// <param name="v">Vector3 向量</param>
    /// <returns>转换后的 Vector2</returns>
    public static Vector2 ToVector2(this Vector3 v) => new Vector2(v.x, v.y);

    /// <summary>
    /// 将 Vector2 转换为 Vector3，将 z 分量设为 0。
    /// </summary>
    /// <param name="v">Vector2 向量</param>
    /// <returns>转换后的 Vector3</returns>
    public static Vector3 ToVector3(this Vector2 v) => new Vector3(v.x, v.y, 0);
}


public static class Vector3New
{
    /// <summary>
    /// 设置新的 X 值。
    /// </summary>
    public static Vector3 NewX(this Vector3 v, float newX) => new Vector3(newX, v.y, v.z);

    /// <summary>
    /// 设置新的 Y 值。
    /// </summary>
    public static Vector3 NewY(this Vector3 v, float newY) => new Vector3(v.x, newY, v.z);

    /// <summary>
    /// 设置新的 Z 值。
    /// </summary>
    public static Vector3 NewZ(this Vector3 v, float newZ) => new Vector3(v.x, v.y, newZ);

    /// <summary>
    /// 同时设置新的 X 和 Y 值。
    /// </summary>
    public static Vector3 NewXY(this Vector3 v, float newX, float newY) => new Vector3(newX, newY, v.z);

    /// <summary>
    /// 同时设置新的 X 和 Z 值。
    /// </summary>
    public static Vector3 NewXZ(this Vector3 v, float newX, float newZ) => new Vector3(newX, v.y, newZ);

    /// <summary>
    /// 同时设置新的 Y 和 Z 值。
    /// </summary>
    public static Vector3 NewYZ(this Vector3 v, float newY, float newZ) => new Vector3(v.x, newY, newZ);

    /// <summary>
    /// 同时设置新的 X、Y 和 Z 值。
    /// </summary>
    public static Vector3 NewXYZ(this Vector3 v, float newX, float newY, float newZ) => new Vector3(newX, newY, newZ);

    /// <summary>
    /// 交换 X 和 Y 值。
    /// </summary>
    public static Vector3 SwapXY(this Vector3 v) => new Vector3(v.y, v.x, v.z);

    /// <summary>
    /// 交换 X 和 Z 值。
    /// </summary>
    public static Vector3 SwapXZ(this Vector3 v) => new Vector3(v.z, v.y, v.x);

    /// <summary>
    /// 交换 Y 和 Z 值。
    /// </summary>
    public static Vector3 SwapYZ(this Vector3 v) => new Vector3(v.x, v.z, v.y);
}


public static class Vector2New
{
    /// <summary>
    /// 设置新的 X 值。
    /// </summary>
    public static Vector2 NewX(this Vector2 v, float newX) => new Vector2(newX, v.y);

    /// <summary>
    /// 设置新的 Y 值。
    /// </summary>
    public static Vector2 NewY(this Vector2 v, float newY) => new Vector2(v.x, newY);

    /// <summary>
    /// 同时设置新的 X 和 Y 值。
    /// </summary>
    public static Vector2 NewXY(this Vector2 v, float newX, float newY) => new Vector2(newX, newY);

    /// <summary>
    /// 交换 X 和 Y 值。
    /// </summary>
    public static Vector2 SwapXY(this Vector2 v) => new Vector2(v.y, v.x);
}


public static class Vector2IntNew{
    /// <summary>
    /// 设置新的 X 值。
    /// </summary>
    public static Vector2Int NewX(this Vector2Int v, int newX) => new Vector2Int(newX, v.y);

    /// <summary>
    /// 设置新的 Y 值。
    /// </summary>
    public static Vector2Int NewY(this Vector2Int v, int newY) => new Vector2Int(v.x, newY);

    /// <summary>
    /// 同时设置新的 X 和 Y 值。
    /// </summary>
    public static Vector2Int NewXY(this Vector2Int v, int newX, int newY) => new Vector2Int(newX, newY);

    /// <summary>
    /// 交换 X 和 Y 值。
    /// </summary>
    public static Vector2Int SwapXY(this Vector2Int v) => new Vector2Int(v.y, v.x);
}


public static class Vector3IntNew
{
    /// <summary>
    /// 设置新的 X 值。
    /// </summary>
    public static Vector3Int NewX(this Vector3Int v, int newX) => new Vector3Int(newX, v.y, v.z);

    /// <summary>
    /// 设置新的 Y 值。
    /// </summary>
    public static Vector3Int NewY(this Vector3Int v, int newY) => new Vector3Int(v.x, newY, v.z);

    /// <summary>
    /// 设置新的 Z 值。
    /// </summary>
    public static Vector3Int NewZ(this Vector3Int v, int newZ) => new Vector3Int(v.x, v.y, newZ);

    /// <summary>
    /// 同时设置新的 X 和 Y 值。
    /// </summary>
    public static Vector3Int NewXY(this Vector3Int v, int newX, int newY) => new Vector3Int(newX, newY, v.z);

    /// <summary>
    /// 同时设置新的 X 和 Z 值。
    /// </summary>
    public static Vector3Int NewXZ(this Vector3Int v, int newX, int newZ) => new Vector3Int(newX, v.y, newZ);

    /// <summary>
    /// 同时设置新的 Y 和 Z 值。
    /// </summary>
    public static Vector3Int NewYZ(this Vector3Int v, int newY, int newZ) => new Vector3Int(v.x, newY, newZ);

    /// <summary>
    /// 同时设置新的 X、Y 和 Z 值。
    /// </summary>
    public static Vector3Int NewXYZ(this Vector3Int v, int newX, int newY, int newZ) => new Vector3Int(newX, newY, newZ);

    /// <summary>
    /// 交换 X 和 Y 值。
    /// </summary>
    public static Vector3Int SwapXY(this Vector3Int v) => new Vector3Int(v.y, v.x, v.z);

    /// <summary>
    /// 交换 X 和 Z 值。
    /// </summary>
    public static Vector3Int SwapXZ(this Vector3Int v) => new Vector3Int(v.z, v.y, v.x);

    /// <summary>
    /// 交换 Y 和 Z 值。
    /// </summary>
    public static Vector3Int SwapYZ(this Vector3Int v) => new Vector3Int(v.x, v.z, v.y);
}


public static class ColorNew
{
    /// <summary>
    /// 设置新的 R 值。
    /// </summary>
    public static Color NewR(this Color color, float newR) => new Color(newR, color.g, color.b, color.a);

    /// <summary>
    /// 设置新的 G 值。
    /// </summary>
    public static Color NewG(this Color color, float newG) => new Color(color.r, newG, color.b, color.a);

    /// <summary>
    /// 设置新的 B 值。
    /// </summary>
    public static Color NewB(this Color color, float newB) => new Color(color.r, color.g, newB, color.a);

    /// <summary>
    /// 设置新的 A 值。
    /// </summary>
    public static Color NewA(this Color color, float newA) => new Color(color.r, color.g, color.b, newA);

    /// <summary>
    /// 同时设置新的 R 和 G 值。
    /// </summary>
    public static Color NewRG(this Color color, float newR, float newG) => new Color(newR, newG, color.b, color.a);

    /// <summary>
    /// 同时设置新的 R 和 B 值。
    /// </summary>
    public static Color NewRB(this Color color, float newR, float newB) => new Color(newR, color.g, newB, color.a);

    /// <summary>
    /// 同时设置新的 R 和 A 值。
    /// </summary>
    public static Color NewRA(this Color color, float newR, float newA) => new Color(newR, color.g, color.b, newA);

    /// <summary>
    /// 同时设置新的 G 和 B 值。
    /// </summary>
    public static Color NewGB(this Color color, float newG, float newB) => new Color(color.r, newG, newB, color.a);

    /// <summary>
    /// 同时设置新的 G 和 A 值。
    /// </summary>
    public static Color NewGA(this Color color, float newG, float newA) => new Color(color.r, newG, color.b, newA);

    /// <summary>
    /// 同时设置新的 B 和 A 值。
    /// </summary>
    public static Color NewBA(this Color color, float newB, float newA) => new Color(color.r, color.g, newB, newA);

    /// <summary>
    /// 同时设置新的 R、G 和 B 值。
    /// </summary>
    public static Color NewRGB(this Color color, float newR, float newG, float newB) => new Color(newR, newG, newB, color.a);

    /// <summary>
    /// 同时设置新的 R、G 和 A 值。
    /// </summary>
    public static Color NewRGA(this Color color, float newR, float newG, float newA) => new Color(newR, newG, color.b, newA);

    /// <summary>
    /// 同时设置新的 R、B 和 A 值。
    /// </summary>
    public static Color NewRBA(this Color color, float newR, float newB, float newA) => new Color(newR, color.g, newB, newA);

    /// <summary>
    /// 同时设置新的 G、B 和 A 值。
    /// </summary>
    public static Color NewGBA(this Color color, float newG, float newB, float newA) => new Color(color.r, newG, newB, newA);

    /// <summary>
    /// 同时设置新的 R、G、B 和 A 值。
    /// </summary>
    public static Color NewRGBA(this Color color, float newR, float newG, float newB, float newA) => new Color(newR, newG, newB, newA);

    /// <summary>
    /// 交换 R 和 G 值。
    /// </summary>
    public static Color SwapRG(this Color color) => new Color(color.g, color.r, color.b, color.a);

    /// <summary>
    /// 交换 R 和 B 值。
    /// </summary>
    public static Color SwapRB(this Color color) => new Color(color.b, color.g, color.r, color.a);

    /// <summary>
    /// 交换 R 和 A 值。
    /// </summary>
    public static Color SwapRA(this Color color) => new Color(color.a, color.g, color.b, color.r);

    /// <summary>
    /// 交换 G 和 B 值。
    /// </summary>
    public static Color SwapGB(this Color color) => new Color(color.r, color.b, color.g, color.a);

    /// <summary>
    /// 交换 G 和 A 值。
    /// </summary>
    public static Color SwapGA(this Color color) => new Color(color.r, color.a, color.b, color.g);

    /// <summary>
    /// 交换 B 和 A 值。
    /// </summary>
    public static Color SwapBA(this Color color) => new Color(color.r, color.g, color.a, color.b);

}


/// <summary>
/// ColorSpace 扩展库，提供了颜色转换和操作的常用方法，
/// 包括 RGB 与 HSL 之间的转换、HSV 空间中的颜色插值、
/// 灰度、反色、亮度和饱和度调整、Alpha 设置以及十六进制字符串与 Color 之间的转换。
/// </summary>
public static class ColorSpace
{
    /// <summary>
    /// 将 RGB 颜色转换为 HSL 颜色值。
    /// 输出的 h、s、l 均归一化到 [0,1] 区间。
    /// </summary>
    /// <param name="color">输入 RGB 颜色</param>
    /// <param name="h">输出色调 (Hue)</param>
    /// <param name="s">输出饱和度 (Saturation)</param>
    /// <param name="l">输出亮度 (Lightness)</param>
    public static void RGBToHSL(Color color, out float h, out float s, out float l)
    {
        float max = Mathf.Max(color.r, color.g, color.b);
        float min = Mathf.Min(color.r, color.g, color.b);
        l = (max + min) / 2f; // 亮度

        if (Mathf.Approximately(max, min))
        {
            // 当所有分量相同，颜色为灰色，无色调和饱和度
            h = 0f;
            s = 0f;
        }
        else
        {
            float d = max - min;
            s = l > 0.5f ? d / (2f - max - min) : d / (max + min);

            if (Mathf.Approximately(max, color.r))
            {
                h = (color.g - color.b) / d + (color.g < color.b ? 6f : 0f);
            }
            else if (Mathf.Approximately(max, color.g))
            {
                h = (color.b - color.r) / d + 2f;
            }
            else
            {
                h = (color.r - color.g) / d + 4f;
            }
            h /= 6f; // 标准化到 0~1
        }
    }
    /// <summary>
    /// 将标准化的 HSL 值转换为 RGB 颜色。
    /// 输入的 h、s、l 应在 [0,1] 范围内，输出颜色的 Alpha 默认为 1。
    /// </summary>
    /// <param name="h">色调 (Hue)，范围 [0,1]</param>
    /// <param name="s">饱和度 (Saturation)，范围 [0,1]</param>
    /// <param name="l">亮度 (Lightness)，范围 [0,1]</param>
    /// <returns>转换后的 RGB 颜色</returns>
    public static Color HSLToRGB(float h, float s, float l)
    {
        // 将 h 从 [0,1] 转换为 [0,360]，便于计算
        float H = Mathf.Clamp01(h) * 360f;
        s = Mathf.Clamp01(s);
        l = Mathf.Clamp01(l);

        float c = (1f - Mathf.Abs(2f * l - 1f)) * s;
        float x = c * (1f - Mathf.Abs((H / 60f) % 2f - 1f));
        float m = l - c / 2f;

        float r, g, b;
        if (H < 60f) { r = c; g = x; b = 0f; }
        else if (H < 120f) { r = x; g = c; b = 0f; }
        else if (H < 180f) { r = 0f; g = c; b = x; }
        else if (H < 240f) { r = 0f; g = x; b = c; }
        else if (H < 300f) { r = x; g = 0f; b = c; }
        else { r = c; g = 0f; b = x; }

        return new Color(r + m, g + m, b + m, 1f);
    }

    /// <summary>
    /// 在 HSV 色彩空间中，对两个颜色进行插值。
    /// Hue 的插值会自动处理 0/1 的环绕问题（例如 350° 与 10°）。
    /// </summary>
    /// <param name="colorA">起始颜色</param>
    /// <param name="colorB">目标颜色</param>
    /// <param name="t">插值因子，范围 [0,1]</param>
    /// <returns>插值后的颜色</returns>
    public static Color LerpHSV(this Color colorA, Color colorB, float t)
    {
        // 将颜色转换为 HSV 表示
        Color.RGBToHSV(colorA, out float h1, out float s1, out float v1);
        Color.RGBToHSV(colorB, out float h2, out float s2, out float v2);

        // 处理 Hue 的环绕插值问题
        float h;
        if (Mathf.Abs(h2 - h1) > 0.5f)
        {
            if (h1 > h2)
                h2 += 1f;
            else
                h1 += 1f;
        }
        h = Mathf.Lerp(h1, h2, t) % 1f;

        // 插值 Saturation 和 Value
        float s = Mathf.Lerp(s1, s2, t);
        float v = Mathf.Lerp(v1, v2, t);

        // 插值 Alpha 通道
        float a = Mathf.Lerp(colorA.a, colorB.a, t);

        // 将 HSV 转换回 RGB，并保留 Alpha 值
        Color rgb = Color.HSVToRGB(h, s, v);
        rgb.a = a;
        return rgb;
    }

    /// <summary>
    /// 对两个颜色进行线性插值（RGB 空间内的插值）。
    /// 该方法是对内置运算符的封装。
    /// </summary>
    /// <param name="from">起始颜色</param>
    /// <param name="to">目标颜色</param>
    /// <param name="t">插值因子，范围 [0,1]</param>
    /// <returns>插值后的颜色</returns>
    public static Color Lerp(this Color from, Color to, float t)
    {
        return from * (1f - t) + to * t;
    }

    /// <summary>
    /// 将颜色转换为灰度值，使用加权平均法（Rec. 709 标准）。
    /// </summary>
    /// <param name="color">输入颜色</param>
    /// <returns>灰度值，范围 [0,1]</returns>
    public static float ToGrayscale(this Color color)
    {
        // 常用权重：红色 0.2126, 绿色 0.7152, 蓝色 0.0722
        return color.r * 0.2126f + color.g * 0.7152f + color.b * 0.0722f;
    }

    /// <summary>
    /// 获取颜色的反色（即各颜色分量取反）。
    /// </summary>
    /// <param name="color">输入颜色</param>
    /// <returns>反色，Alpha 保持不变</returns>
    public static Color Invert(this Color color)
    {
        return new Color(1f - color.r, 1f - color.g, 1f - color.b, color.a);
    }

    /// <summary>
    /// 调整颜色的亮度，通过乘以一个亮度因子来实现，
    /// 保持颜色的色相不变。
    /// </summary>
    /// <param name="color">输入颜色</param>
    /// <param name="brightness">亮度因子（1 为不变，大于 1 增亮，小于 1 降暗）</param>
    /// <returns>调整后的颜色</returns>
    public static Color AdjustBrightness(this Color color, float brightness)
    {
        return new Color(Mathf.Clamp01(color.r * brightness),
                         Mathf.Clamp01(color.g * brightness),
                         Mathf.Clamp01(color.b * brightness),
                         color.a);
    }

    /// <summary>
    /// 调整颜色的饱和度。
    /// 先将颜色从 RGB 转换到 HSL，再调整饱和度后转换回 RGB。
    /// </summary>
    /// <param name="color">输入颜色</param>
    /// <param name="saturation">饱和度因子（1 为不变，大于 1 增加饱和度，小于 1 降低饱和度）</param>
    /// <returns>调整后的颜色</returns>
    public static Color AdjustSaturation(this Color color, float saturation)
    {
        RGBToHSL(color, out float h, out float s, out float l);
        s = Mathf.Clamp01(s * saturation);
        return HSLToRGB(h, s, l);
    }

    /// <summary>
    /// 设置颜色的 Alpha 值（透明度）。
    /// </summary>
    /// <param name="color">输入颜色</param>
    /// <param name="alpha">新的 Alpha 值，范围 [0,1]</param>
    /// <returns>调整后的颜色</returns>
    public static Color SetAlpha(this Color color, float alpha)
    {
        return new Color(color.r, color.g, color.b, Mathf.Clamp01(alpha));
    }

    /// <summary>
    /// 将颜色转换为不含 Alpha 的十六进制字符串表示（格式为 "#RRGGBB"）。
    /// </summary>
    /// <param name="color">输入颜色</param>
    /// <returns>十六进制字符串，如 "#FFFFFF"</returns>
    public static string ToHex(this Color color)
    {
        int r = Mathf.RoundToInt(color.r * 255f);
        int g = Mathf.RoundToInt(color.g * 255f);
        int b = Mathf.RoundToInt(color.b * 255f);
        return $"#{r:X2}{g:X2}{b:X2}";
    }

    /// <summary>
    /// 将十六进制字符串转换为 Color 对象。支持格式 "#RRGGBB" 和 "#RRGGBBAA"。
    /// </summary>
    /// <param name="hex">十六进制字符串，如 "#FFFFFF" 或 "#FFFFFFFF"</param>
    /// <returns>转换后的颜色</returns>
    public static Color HexToColor(this string hex)
    {
        // 移除可能存在的 '#' 前缀
        if (hex.StartsWith("#"))
            hex = hex.Substring(1);

        byte r = 255, g = 255, b = 255, a = 255;

        if (hex.Length == 6)
        {
            r = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
            g = byte.Parse(hex.Substring(2, 2), NumberStyles.HexNumber);
            b = byte.Parse(hex.Substring(4, 2), NumberStyles.HexNumber);
        }
        else if (hex.Length == 8)
        {
            r = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
            g = byte.Parse(hex.Substring(2, 2), NumberStyles.HexNumber);
            b = byte.Parse(hex.Substring(4, 2), NumberStyles.HexNumber);
            a = byte.Parse(hex.Substring(6, 2), NumberStyles.HexNumber);
        }
        else
        {
            Debug.LogError("无效的十六进制字符串长度，必须为 6 或 8 个字符。");
        }

        return new Color(r / 255f, g / 255f, b / 255f, a / 255f);
    }
}
