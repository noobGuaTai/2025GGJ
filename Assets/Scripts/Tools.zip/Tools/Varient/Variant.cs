using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;

abstract public class VariantData
{
    public abstract object DataObject{ get; }
    public abstract Type Type{ get; }
    public static Dictionary<Type, TypeOP> registedType = new();
    public class TypeOP{}
    public class TypeOP<T> : TypeOP
    {
        public Func<T, T, bool> opEQ;
    }
    public class RegisterT<T> 
    {
        public RegisterT(Func<T, T, bool> opEQ)
        {
            registedType[typeof(T)] = new TypeOP<T> { opEQ = opEQ };
        }
    }
}
public class VariantObj : VariantData
{
    public object data;
    public override object DataObject => data;
    public override Type Type => data.GetType();
}
public class VariantData<T> : VariantData
{
    public T data;
    static Type dataType = typeof(T);
    public override Type Type => dataType;
    public override object DataObject => data;
    public override bool Equals(object obj)
        => (obj is VariantData<T> other) && data.Equals(other.data);
        
        // if (obj is Variant<T> other)
        // {
        //     return data.Equals(obj);
        //     //return Unsafe.As<TypeOP<T>>(registedType[Type]).opEQ(data, other.data);
        // }
        // return false;
    public override int GetHashCode() => data.GetHashCode();
    static public implicit operator VariantData<T>(T x) => new VariantData<T>() { data = x };
}
public class Variant
{
    VariantData varData = null;
    public Type Type => varData.Type;
    public Variant() { }
    public static Variant New<T>(T x)
    {
        if (typeof(T) == typeof(object))
            return new Variant() { varData = new VariantObj() { data = x } };
        return new Variant() { varData = new VariantData<T>() { data = x } };
    }
    public T Get<T>()
    {
        Convert_<T>();
        var this_ = this as VariantData<T>;
        return this_.data;
    }
    public ref T As<T>()
    {
        Convert_<T>();
        var this_ = this as VariantData<T>;
        return ref this_.data;
    }
    public void Set<T>(T value)
    {
        if (varData == null)
        {
            varData = new VariantData<T>() { data = value };
            return;
        }
        Convert_<T>();
        var this_ = this as VariantData<T>;
        this_.data = value;
    }
    public void Convert_<U>()
    {
        var varData_ = varData as VariantObj;
        if (varData_ != null)
            varData = new VariantData<U>() { data = (U)varData_.data };
    }
    static public string Var2Str(Dictionary<string, Variant> x)
    {
        var str = new StringBuilder();
        str.Append("{");
        foreach (var p in x)
            str.Append($"{p.Key}:{Var2Str(p.Value)},");
        str.Append("}");
        return str.ToString();
    }
    static Type[] BasicType = { typeof(int), typeof(float), typeof(string) };
    static Dictionary<Type, Func<Variant, string>> Var2StrCache = new();
    static public string Var2Str(Variant x)
    {
        var flag = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        var type = x.varData.Type;

        if (!Var2StrCache.TryGetValue(type, out var func))
        {
            var exports = type.GetFields(flag).ToList().Where(x => x.GetCustomAttribute<VariantExport>() != null);
            func = (x) =>
            {
                if (BasicType.Contains(x.Type))
                    return x.varData.ToString();

                var dict = new Dictionary<string, Variant>();
                foreach (var ev in exports)
                    dict[ev.Name] = New(ev.GetValue(x));
                dict["$Assembly"] = New(x.Type.Assembly.FullName);
                dict["$Type"] = New(x.Type.FullName);
                return Var2Str(dict);
            };
            Var2StrCache[type] = func;
        }
        return func(x);
    }
    static public Dictionary<string, string> Str2Dict(string x)
    {
        var dict = new Dictionary<string, string>();
        var keyValue = x[1..].Split(",").SkipLast(1).ToList();
        for (int i = 0; i < keyValue.Count; i++)
        {
            var kv = keyValue[i];
            var kvs = kv.Split(":").ToList();
            var k = kvs[0];
            if (kvs[1][0] == '\"')
            {
                var v = new List<string>();
                Func<bool> end = () =>
                    v.Last().Last() == '\"' && (v.Last().Count() == 1 || v.Last()[^2] != '\\');
                v.Append(kvs[1][1..]);
                for (int ii = 2; ii < kvs.Count; ii++)
                    v.Append(kvs[ii]);
                while (!end())
                {
                    i++;
                    v.Add(keyValue[i]);
                }
                dict[k] = $"\"{v}";
            }
            else dict[k] = kvs[1];
        }
        return dict;
    }
    static Dictionary<(string, string), Func<Dictionary<string, string>, object>> Dict2ObjectCache = new();
    static public object Str2Object(string x)
    {
        if (x[0] == '{')
        {
            var flag = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            var dict = Str2Dict(x);
            var assemType = (dict["$Assembly"], dict["$Type"]);
            if (!Dict2ObjectCache.TryGetValue(assemType, out var func))
            {
                var assem = Assembly.Load(dict["$Assembly"][1..^1]);
                var type = assem.GetType(dict["$Type"][1..^1]);
                var exports = type.GetFields(flag).ToList().Where(x => x.GetCustomAttribute<VariantExport>() != null);
                func = (dict) =>
                {
                    var obj = Activator.CreateInstance(type);
                    foreach (var e in exports)
                    {
                        if (!dict.TryGetValue(e.Name, out var v))
                            continue;
                        e.SetValue(obj, Str2Var(v).varData.DataObject);
                    }
                    return obj;
                };
                Dict2ObjectCache[assemType] = func;
            }
            return func(dict);
        }
        else if (x[0] == '\"')
            return x[1..^1];
        else if (x.Contains('.'))
            return float.Parse(x);
        else return int.Parse(x);
    }
    static public Variant Str2Var(string x)
        => New(Str2Object(x));

    public ref int Int => ref As<int>();
    public ref float Float => ref As<float>();
    public ref string String => ref As<string>();
    public ref Vector2 Vector2 => ref As<Vector2>();
    public ref Vector3 Vector3 => ref As<Vector3>();
    public ref Color Color => ref As<Color>();
    public override bool Equals(object obj)
    {
        if (!(obj is Variant other)) return false;
        return Type == other.Type && varData.Equals(other.varData);
    }
    public override int GetHashCode()
        => varData.GetHashCode();


}

[AttributeUsage(AttributeTargets.Property)]
public class VariantExport : System.Attribute
{}
