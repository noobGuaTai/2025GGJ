
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using CsvHelper.TypeConversion;
using NUnit.Framework;
public abstract class TypeOPInsBase {
    public abstract R_ OP<X1_, X2_, R_>(X1_ x1, X2_ x2);
    public abstract object OP(object x1, object x2);
}
public class TypeOPIns2<X1, X2, R> : TypeOPInsBase
{
    public Func<X1, X2, R> op;

    public override R_ OP<X1_, X2_, R_>(X1_ x1, X2_ x2)
    {
        if (typeof(R) != typeof(R_))
            throw new Exception($"return Type {typeof(R_)} != {typeof(R)}(original)");
        return Unsafe.As<Func<X1_, X2_, R_>>(op)(x1, x2);
    }

    public override object OP(object x1, object x2)
    {
        object x = 1;
        var t = x as int?;
        return op((X1)x1, (X2)x2);
    }
}
public class TypeOP
{
    static Dictionary<(Type, Type), TypeOPInsBase> Add = new();
    static Dictionary<(Type, Type), TypeOPInsBase> Sub = new();
    static Dictionary<(Type, Type), TypeOPInsBase> Mul = new();
    static Dictionary<(Type, Type), TypeOPInsBase> Div = new();
    static public void AddOP_Add<R, X1, X2>(Func<R, X1, X2> op) => Add.Add((typeof(X1), typeof(X2)), new TypeOPIns2<R, X1, X2>(){op = op});
    static public R OP_Add<X1, X2, R>(X1 x1, X2 x2)
    {
        if (!Add.TryGetValue((typeof(X1), typeof(X2)), out var opIns))
            throw new NotImplementedException();
        return opIns.OP<X1, X2, R>(x1, x2);
    }
    static public object OP_Add(Type t1, object x1, Type t2, object x2)
    {
        if (!Add.TryGetValue((t1, t2), out var opIns))
            throw new NotImplementedException();
        return opIns.OP(x1, x2);
    }
}